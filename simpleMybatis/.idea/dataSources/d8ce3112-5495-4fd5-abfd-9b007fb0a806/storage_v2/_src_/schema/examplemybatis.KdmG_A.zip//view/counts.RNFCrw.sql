create definer = root@localhost view counts as
select `usercount`.`usercount`             AS `usercount`,
       `deptcount`.`deptcount`             AS `deptcount`,
       `employeecount`.`employeecount`     AS `employeecount`,
       `jobcount`.`jobcount`               AS `jobcount`,
       `uploadfilecount`.`uploadfilecount` AS `uploadfilecount`,
       `rolecount`.`rolecount`             AS `rolecount`,
       `noticecount`.`noticecount`         AS `noticecount`
from ((((((`examplemybatis`.`usercount` join `examplemybatis`.`deptcount`) join `examplemybatis`.`employeecount`) join `examplemybatis`.`jobcount`) join `examplemybatis`.`uploadfilecount`) join `examplemybatis`.`rolecount`)
         join `examplemybatis`.`noticecount`);

