create definer = root@localhost view deptcount as
select count(0) AS `deptcount`
from `examplemybatis`.`employee`;

