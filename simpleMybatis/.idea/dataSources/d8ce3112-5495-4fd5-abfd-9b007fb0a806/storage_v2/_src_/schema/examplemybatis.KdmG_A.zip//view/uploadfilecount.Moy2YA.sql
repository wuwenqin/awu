create definer = root@localhost view uploadfilecount as
select count(0) AS `uploadfilecount`
from `examplemybatis`.`uploadfile`;

