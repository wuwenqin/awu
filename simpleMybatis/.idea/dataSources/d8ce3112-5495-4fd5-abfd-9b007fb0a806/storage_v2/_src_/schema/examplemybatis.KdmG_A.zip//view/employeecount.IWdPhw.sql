create definer = root@localhost view employeecount as
select count(0) AS `employeecount`
from `examplemybatis`.`employee`;

