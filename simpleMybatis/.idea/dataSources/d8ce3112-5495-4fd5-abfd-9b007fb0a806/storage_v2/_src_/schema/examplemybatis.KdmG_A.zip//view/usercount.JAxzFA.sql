create definer = root@localhost view usercount as
select count(0) AS `usercount`
from `examplemybatis`.`user`;

