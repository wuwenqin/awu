create definer = root@localhost view noticecount as
select count(0) AS `noticecount`
from `examplemybatis`.`notice`;

