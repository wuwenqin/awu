create definer = root@localhost view jobcount as
select count(0) AS `jobcount`
from `examplemybatis`.`job`;

