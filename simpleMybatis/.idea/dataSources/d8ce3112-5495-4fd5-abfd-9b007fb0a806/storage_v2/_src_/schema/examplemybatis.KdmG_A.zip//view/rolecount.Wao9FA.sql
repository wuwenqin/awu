create definer = root@localhost view rolecount as
select count(0) AS `rolecount`
from `examplemybatis`.`role`;

